version = 2

cloudstream {
    description = "Not recommended for series."
    authors = listOf( "Spoonge" )
	
	language = "ar"

    status = 1

    tvTypes = listOf( "Movie" )

    iconUrl = "https://www.google.com/s2/favicons?domain=movizland.cyou&sz=%size%"
}