version = 7

cloudstream {
    description = "Egybest is broken"
    authors = listOf( "ImZaw" )

	language = "ar"
	
    status = 0

    tvTypes = listOf( "TvSeries" , "Movie" , "Anime" )

    iconUrl = "https://www.google.com/s2/favicons?domain=www.egy.best&sz=%size%"
}
