# Arabic providers repository for CloudStream

[Download](https://cutt.ly/dirar)

[Site request](https://github.com/ImZaw/cloudstream-extensions-arabic/issues/8)
