version = 1

cloudstream {
    description = ""
    authors = listOf( "Spoonge" )
    language = "ar"
    status = 1

    tvTypes = listOf( "Movie")

    iconUrl = "https://www.google.com/s2/favicons?domain=www.fushaar.com&sz=%size%"
}
